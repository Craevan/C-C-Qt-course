#ifndef C_C_QT_COURSE_STATUS_H
#define C_C_QT_COURSE_STATUS_H


enum class Status {
    outOfBoundsInput,
    alreadyOccupied,
    validInput,
    draw,
    winner
};


#endif
