#include <iostream>
#include "view/GameView.h"

int main() {
    std::cout<< "XO-CLI_ver.0.1_alpha"<<std::endl;
    GameView game;
    return 0;
}
